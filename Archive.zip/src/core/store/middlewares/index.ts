import logger from './logger';
// import saga from './saga';
//
const middlewares = [logger];
export default middlewares;

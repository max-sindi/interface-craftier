import React from 'react';
import { ExtendedNode } from 'src/core/ExtendedNode';
// import clsx from 'classnames';

interface ILiveTagManagerProps {
  nodeState: ExtendedNode;
}

const LiveTagManager = (props : ILiveTagManagerProps) => {
  return (
    <>

    </>
  );
};

export default LiveTagManager;

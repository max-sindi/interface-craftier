"use strict";
exports.__esModule = true;
var MediaPoint = /** @class */ (function () {
    function MediaPoint(name, point) {
        this.name = name;
        this.point = point;
    }
    return MediaPoint;
}());
// class MediaStorage {
//     public readonly storage: IStorage
// }
// const storage = new MediaStorage()
var Media = /** @class */ (function () {
    // breakpoint: number
    // private readonly media: MediaPoint[]
    // private
    function Media(enable) {
        // if(!enable) return
        //
        // this.media = [
        //     new MediaPoint('lg', 1200),
        //     new MediaPoint('md', 750),
        //     new MediaPoint('sm', 440),
        // ]
        // this.breakpoint = breakpoint
    }
    return Media;
}());
exports["default"] = Media;

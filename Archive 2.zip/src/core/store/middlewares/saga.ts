// import createSagaMiddleware from 'redux-saga';
// import rfpsSaga from 'store/modules/rfp/saga';
// import profileSaga from 'store/modules/profile/saga';
// import performanceSaga from 'store/modules/performance/saga';
//
// const sagaMiddleware = createSagaMiddleware();
//
// // add new sagas here
// const sagas = [rfpsSaga, profileSaga, performanceSaga];
//
// export default sagaMiddleware;
// export { sagas };

import { createSelector } from '@reduxjs/toolkit';
import { RootReducer } from '../../../store/rootReducer';

// const reducerSelector = (state: RootReducer) => state.;

// export const  = createSelector(reducerSelector, (state) => state);

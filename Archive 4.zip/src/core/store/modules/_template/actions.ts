import { createAction } from '@reduxjs/toolkit';

const action = createAction<any>('/* action name */');
